
GitHub Actions Android Build
============================

Este projeto já vem com um workflow em `.github/workflows/android-build.yml`
para compilar automaticamente um APK Android (modo debug).

Como usar:
1. Suba este projeto para um repositório no GitHub (branch principal: `main`).
2. Vá em "Actions" no repositório e rode o workflow `Build Godot Android APK` manualmente (ou faça um push para `main`).
3. Após alguns minutos, o workflow gera um APK e disponibiliza como artefato chamado **DeadRails-APK**.
   - Baixe o APK em: Actions → Workflow run → Artifacts → DeadRails-APK.

Assinatura:
- Este APK é gerado em modo DEBUG (sem keystore própria). Serve para testes em qualquer celular Android.
- Para publicar na Play Store, você precisa adicionar sua keystore e configurar no export_presets.cfg.

Arquivo de configuração:
- O `export_presets.cfg` é gerado automaticamente pelo workflow antes da exportação.
- Ele define um preset "Android Debug" que exporta para `builds/DeadRails-debug.apk`.

Se quiser, você pode editar `export_presets.cfg` localmente, adicionar assinatura de release e depois subir no GitHub.

