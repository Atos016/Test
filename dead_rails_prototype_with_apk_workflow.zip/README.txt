
Dead Rails - 2D Prototype (Godot 4)
---------------------------------
What's included:
- scenes/Main.tscn     : main scene (Node2D)
- scenes/Player.tscn   : player scene (CharacterBody2D-like)
- scripts/player.gd    : player code (lane switching + shooting)
- scripts/bullet.gd    : bullet behavior
- scripts/enemy.gd     : simple enemy that moves toward player
- assets : colored placeholder sprites generated as small PNGs

How to open:
1. Install Godot 4.1 (or 4.0+).
2. Extract this zip into a folder and open it in Godot (Project -> Import -> select project.godot).
3. Run the Main scene.

Notes about APK export:
- I cannot build an APK inside this environment.
- To export to Android you must:
  1) Install Android SDK (Android Command Line Tools) and Java JDK.
  2) Download Godot Android export templates (Project -> Install Android Build Template in Godot or via AssetLib).
  3) In Godot Editor: Project -> Install Android SDK, configure paths to SDK, JDK, and Android SDK Platform (API 31+ recommended).
  4) Configure a keystore (or use debug keystore) and export (Project -> Export -> Android).
- Alternatively, services like GitHub Actions or a local machine can build the APK for you using Godot CLI.

Files and code are small and heavily commented to help you continue the game.
If you want, I can also adapt this to Unity or provide steps to compile on Replit/GitHub Actions. Tell me which you prefer.
